## 一、css hack

#### 1.条件hack

* ie10及以上版本已废弃

```
 	<!--[if IE]>
        <p>ie浏览器显示</p>
    <![endif]-->

    <!--[if !lte ie 7]>
     <p>小于等于ie7</p>
    <![endif]-->
```

* gt  大于
* gte  大于等于
* lt   小于
* lte  小于等于
* ！   非

#### 2.属性级hack

 _下划线：选择IE6及以下          

 *：选择IE7及以下

```
*background-color: red;
_background-color: red;

            background-color: blue\9;   ie6+
            background-color: blue\0;   ie8+
```



## 二、ie浏览器兼容

#### 1.图片边框   ie10及以下

* 图片外套一层a标签时，会出现边框

  ```
   img{
     border: none;
  }
  ```

#### 2.表单聚焦时有黑色边框

```
input{
   outline: none;
}
```

#### 3.背景复合写法问题  ie8及以下

* url和后边样式没有加空格引起的

```
 background: red url(./1.png) no-repeat;
```

#### 4.转内联块不在一行显示  ie7及以下

```
.box{
            display: inline-block;
            *display: inline;
            *zoom: 1;
        }
```

#### 5.当 li 中出现 2 个或以上的浮动时，li之间产生的空白间隙  ie7及以下

```
vertical-align:top |  middle | bottom
```

#### 6.子标签相对定位时父标签 overflow 属性的 auto|hidden 失效的问题   ie6  和 ie7

```
给父元素也加一个相对定位即可
```

#### 7.小高度问题  ie6及以下

```
      font-size: 0px;
       line-height: 0px;
        overflow: hidden;
```

#### 8.浮动时产生双倍边距的 BUG  

```
 _display:inline;
```

#### 9.小三角透明  ie6及以下

```
将透明方向的边框样式设置为 dotted 或者  dashed
```



