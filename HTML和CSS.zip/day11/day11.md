---
typora-copy-images-to: videoAudio
typora-root-url: videoAudio
---

## 一、html5新特性

* 内容结构更加简洁
* 新增了结构标签
* 新增了音频和视频
* 新增了表单相关内容
* canvas画布
* 对本地存储有更好的支持
* 拖拽
* 地图



## 二、新增的结构标签

1.header  头部（logo,搜索框）

2.nav   导航（导航，侧边导航，翻页）

3.footer 底部 （友情链接，版权信息）

4.article  一篇完整的文章，博客，用户评论

5.section  一个章节 一般由标题和内容组成

6.aside   和内容相关联，参考文献

7.figure  独立的流内容  ， 图片，代码段，删除后不影响页面布局

8.figcaption  figure里的标题，一个figure里只能有一个标题

9.hgroup  标题组

10.address  作者，联系方式，邮箱

11.mark  标记标签  , 内联标签，默认是黄色背景

12. time  时间

    ```
     <time datetime="2021-2-12">春节</time>
    ```

    

## 三、新增标签兼容

#### 1.创建标签

* 创建的标签是内联标签，需要转块

```
   <script>
        document.createElement('header')
        document.createElement('nav')
        document.createElement('footer')
    </script> 
```



#### 2.引入html5shiv.js插件

```
  <!--[if lte ie 8]>
        <script src="./html5shiv.js"></script>
    <![endif]-->
```



## 四、音频

```
 <audio src="./videoAudio/biubiubiu.ogg" controls>您浏览器版本太低啦，赶紧升级吧</audio>
 
 
   <audio controls>
        <source src="./videoAudio/biubiubiu11.ogg" type="audio/ogg">
        <source src="./videoAudio/nada1111.wav">
        <source src="./videoAudio/hanmai.mp3">
        您浏览器版本太低啦，赶紧升级吧
    </audio>
```

* 属性
  * src用来指定音频路径
  * controls  播放控件
  * loop  是否循环播放
  * muted  静音播放

* 所支持的格式

<img src="/image-20210112105629057.png" alt="image-20210112105629057" style="zoom: 80%;" />



## 五、视频

```
<video src="./videoAudio/despacito.mp4" controls muted loop width="500" height="500" poster="./1.png"></video>


 <video controls  width="300px" height="300px">
        <source src="./videoAudio/movie111.mp4">
        <source src="./videoAudio/PPAP111.webm">
        <source src="./videoAudio/despacito.ogg">
            浏览器不支持
    </video>
```

* 属性

  * src  指定文件路径
  * controls  播放控件
  * muted  静音播放
  * loop  循环播放
  * widht / height   视频宽高，视频不会拉伸变形，会有空白
  * poster   指定封皮图片    ,  图片路径

* 格式

  <img src="/image-20210112113502925.png" alt="image-20210112113502925" style="zoom:80%;" />

## 六、source标签

* 用来指定文件路径，  一般配合  audio  和  video   标签使用
* 如果引入多个音频，首先播放第一个，如果第一个路径错误或不支持，就播放第二个，依次类推
* 属性
  * src  指定文件路径
  * type  指定文件类型



## 七、表单新增

#### 1.type属性新增

* url   网址   若输入格式不正确会阻止表单提交并提示，移动端会弹出带有www  .com键盘
* tel  电话号   移动端会弹出数字键盘
* email  邮箱   若输入格式不正确会阻止表单提交并提示
* number  数字   
  * min 最小值   max 最大值   step 步长
* search  搜索框  最右边有叉号，可清楚该输入框内容
* range  滑块  
  * min 最小值   max 最大值   step 步长
* color  颜色
* date   选取 年月日   若选择不完整会阻止表单提交并提示
* datetime  手动输入时间
* datetime-local  选取年月日 时分   若选择不完整会阻止表单提交并提示
* month  选取  年月  若选择不完整会阻止表单提交并提示
* time  选取 时分  若选择不完整会阻止表单提交并提示
* week  选取年 周   若选择不完整会阻止表单提交并提示



#### 2.datalist标签

* 自定义的下拉列表

* 给datalist起id名， 通过list属性绑定相应的下拉列表

  ```
   <input type="url" name="url" list="mylist">
  
          <datalist id="mylist">
              <option value="https://www.baidu.com">百度</option>
              <option value="https://www.jd.com">京东</option>
              <option value="http://www.淘宝.com">淘宝</option>
              <option value="http://www.ujiuye.com">优就业</option>
          </datalist>
  ```

  

#### 3.表单新增属性

* min  |   max   |step    最小值  | 最大值 |步长

* autofocus  自动聚焦

* autocomplete   自动补全信息，仅限于之前已提交过的内容      on (默认开启)   off   关闭

* required   必填项

* pattern   设置输入框内容的格式

  * []  用来限定输入框能输入的值

  * {}  用来限定输入框输入的个数

    ```
    <input type="text" autocomplete="on" name="txt1" pattern="[0-9a-z]{3,6}">
    ```

* multiple   多文件上传
* form   表单外的输入框也可提交

```
<input type="text" name="out" form="myform">

<form id='myform'></form>
```

* list   用来绑定自定义下拉列表