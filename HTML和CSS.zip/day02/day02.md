## 一、表格

* 用途：最早是用来布局的，现在明显是表格数据的部分才用表格（比如：成绩单，后台管理系统）

#### 1.表格标签

* 块标签
  * table  整个表格的大盒子，所有表格相关内容都要放到table标签里
  * tr   表格里一行
  * caption  表格标题，一个表格里只能有一个标题
  * thead    表头语义    ， 一个表格只能有一个表头
  * tbody    表格主题   ，  可以多个
  * tfoot    页脚  ，  一个表格只能有一个页脚

* 内联块
  * th  单元格 ， 有表头的语义
  * td 单元格，普通单元格

#### 2.表格属性

* border   边框，设置到table 标签上  （了解）
* width    宽度，可设置到单元格上，当前单元格所在那一列的宽度都会改变； 可设置到table上，表格中所有列按照内容宽度比例进行分配宽度
* height 高度，可设置到单元格上，当前单元格所在那一行的高度都会改变； 可设置到table上，表格中所有行按照内容高度比例进行分配高度
* cellspacing   设置到table标签上，控制单元格与单元格之间的空隙
* cellpadding  设置到table标签上，控制单元格边框线到内容的空隙
* rowspan    设置到单元格上，跨行合并
* colspan     设置到单元格上，跨列合并

* align    设置到单元格上是让该单元格内容居中，设置到tr上是让该行所有内容居中，设置到table上是让整个表格在页面中居中（了解）



#### 3.表格样式

* border-collapse : collapse ;   合并单元格边框线    

```
了解：
border-collapse: separate; (默认值，单元格边框线相互独立)
border-spacing: 30px 20px;  //设置单元格与单元格之间的空隙，前提是border-collapse值为默认值
			               //一个值： 四周空隙
                           //两个值： 左右空隙  上下空隙
```

* border    边框线

  ```
  		th{
              border: 5px solid red; //  边框粗细  solid（实线）  边框颜色
          }
  
          td{
              border: 5px solid red;
          }
  ```

  

#### 4.thead  tbody  tfoot好处

* 改变代码顺序，也可以正常显示
* 如果表格巨大时，通过tbody分段，可以加载一段显示一段，用户体验更好



## 二、列表（块标签）

#### 1.有序列表

* 应用场景：页面中有顺序的地方可用，比如：排名，排行榜，步骤

* ol  里边固定嵌套li 
* li 的父元素只能是ol  或者  ul

```
 <ol type="I" start="3" reversed>
         <li>星星在唱歌</li>
         <li>过</li>
         <li> <a href="#">声声慢</a> </li>
         <li>在哪里都很好</li>
         <li>在哪里都很好</li>
     </ol>
```

* ol标签上属性（了解）
  * type   设置列表前的序列号     1   a  A  I  i
  * start  设置顺序是从几开始 
  * reversed   倒序

#### 2.无序列表

* 应用场景： 页面中结构相同，样式相同可用， 比如：导航，商品列表
* ul里固定嵌套li

```
 <ul type='square'>
         <li>
             html
             <ul>
                 <li>html4</li>
                 <li>html5</li>
             </ul>

         </li>
         <li>css</li>
         <li>js</li>
     </ul>
```

* ul标签上的属性（了解）
  * type:   disc(默认，小黑点)   |  circle(空心圆)   |  square(小方块)

#### 3.自定义列表

* 应用场景：页面中有需要对小标题进行解释说明的可用，比如：京东的侧边导航

* dl里固定嵌套 dt  和  dd

* dt 和 dd   是兄弟关系

* dd 是对dt的解释说明

  ```
     <dl>
           <dt>素菜</dt>
           <dd>小白菜</dd>
           <dd>香菜</dd>
           <dd>土豆片</dd>
           <dd>土豆丝</dd>
           <dd>土豆块</dd>
  
           <dt>荤菜</dt>
           <dd>牛肉片</dd>
           <dd>牛肉粒</dd>
           <dd>牛肉卷</dd>
           <dd>羊肉卷</dd>
           <dd>乌鸡卷</dd>
       </dl>
  ```

  

#### 4.列表上css样式

* 取消有序列表和无序列表前边的序列号

```
  <style>
        ul{
            list-style: none;
        }
        ol{
            list-style: none;
        }
    </style>
```



## 三、css引入方式

#### 1.内部样式

* 在head标签里 写style标签，在style标签里写样式

  ```
  <style>
          div{
              width: 100px;
              height: 100px;
              background-color: red;
          }
  </style>
  ```

  

#### 2.行间样式(慎用)

* 在开始标签里写 style属性，在style属性里写样式

  ```
  <p style="width: 100px; height: 100px; background-color: green;">行间样式</p>
  ```

  

#### 3.外部样式

* 现在外边新建一个css文件，在页面的head标签里通过link标签引入css文件

  ```
  <link rel="stylesheet" href="./style.css" type="text/css">
    
          rel="stylesheet"  当前页面和要引入文件的关系
          href="./style.css"  指定要引入的css文件路径
          type="text/css"     指定引入的文件是css文件 
  ```



## 四、css引入方式优先级

一般情况： 行间样式  >   内部样式  >  外部样式  （内部和外部，遵循就近）

* 遵循就近原则



## 五、css基本选择器

#### 1.标签选择器

```
div{
            width: 100px;
            height: 100px;
            background-color: red;
} 
```

#### 2.class选择器

```
html
 <div class="box son">3</div>
 
css
	 .box{
            width: 100px;
            height: 100px;
            background-color: pink;
        }
```

* 一个标签上可以设置多个class名，中间用空格隔开
* 一个class名可以设置到多个标签上

* 命名规则 （id 一样的）
  * 不能以数字开头
  * 区分大小写
  * 见名知意
    * header  头部
    * nav   导航
    * content  内容
      * content-left   左边内容
      * content-right  右边内容
    * footer底部
  * 特殊符号只用   中划线和下划线

#### 3.id选择器

```
html
	<div id="box2">2</div>
css
  #box2{
            width: 200px;
            height: 200px;
            background-color: red;
  }
```

* id是具有唯一性
* 一个标签只能有一个id名



#### 4.通配符  *

* 一般是用来清除标签上自带的样式

* 能选中当前页面中所有的标签

  ```
  *{
     list-style: none;
  }
  ```

  

## 六、基本选择器的优先级

 id选择器   >    class选择器   >    标签选择器   >  通配符

