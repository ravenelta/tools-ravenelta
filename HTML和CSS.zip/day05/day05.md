## 一、标签类型相互转换

#### 1.块标签

​	div    h1-h6    p    hr     table   tr    caption    ul li    ol     dl  dt  dd

#### 2.内联标签

​	strong   b    em   i    sub  sup   span   del    a   br    

#### 3.内联块标签

​	img   th   td



#### 4.相互转换

* display:block    转为块标签
* display: inline    转为内联标签
* display:inline-block   转为内联块标签
* display:none     隐藏标签，原来位置不占位，   display值为三大类中任意一类即可显示



#### 5.标签使用注意事项

* 块标签里可以放块标签，内联标签，内联块标签，但是p标签除外，p标签里不能在放块标签
* 内联标签里不能放块标签，a标签除外，但是a标签里不能在放a标签
* 内联标签不能使用上下的内边距和外边距



## 二、内联块垂直对齐方式

* vertical-align:   baseline(默认值，基线对齐)   |   top    |   bottom   |   middle(中)



## 三、溢出操作

```
            overflow: hidden;（溢出部分隐藏）
            overflow: scroll; （x轴 y轴都有滚动条）
            overflow: auto;  （超出有滚动条，不超出就没有滚动条）
            overflow: visible; (默认值)
            
            
            overflow-y: scroll;
            overflow-x: scroll;
```



## 四、伪元素

* 通过css样式创建的标签就叫伪元素
* 必须配合content 样式使用
* 伪元素默认是内联标签

```
      .box:before{   //在box里第一行创建的伪元素
            content: 'hhhhh';
            width: 100px;
            height: 100px;
            background-color: red;
            display: inline-block;
        }

        .box:after{  //在box里最后一行创建伪元素
            content: '';
            width: 100px;
            height: 100px;
            background-color:orange;
            display: inline-block;
            vertical-align: top;
        }
```



## 五、浮动

* 让多个盒子在一行显示
* 在一行的盒子，每个盒子都要加浮动
* float:  right   |  left   |  none



#### 1.浮动特点

* 给一个盒子加浮动后，该盒子会在**当前行**按照指定方向浮动
* 脱离文档流不占位，不脱离文本流
* 多个盒子一行放不下会自动换行
* 如果块标签没有设置固定宽度，设置浮动后，宽度是由内容撑开的
* 内联标签设置浮动后，就支持宽高



#### 2.浮动产生问题

* 子元素设置浮动后，父元素高度撑不起来

* 解决办法

  * 给父元素设置固定高度 （不灵活）

  * 给父元素设置overflow: auto | hidden   |  scroll

  * 在浮动元素的最下边写一个空的块标签，给该标签设置clear: both |  left   |  right

  * 给父元素设置after伪元素

    ```
     		.clearfix:after{
                content: '';
                display: block;
                clear: both;
            }
            .clearfix{
                *zoom: 1;   // 兼容ie7及以下版本
            }
    ```

    