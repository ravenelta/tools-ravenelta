---
typora-copy-images-to: img
typora-root-url: img
---

## 一、animate.css  动画库

#### 1.引入css文件

```
<link rel="stylesheet" href="animate.min.css">
```

#### 2.HTML 及使用

```
旧版
<div class="animated bounce" id="dowebok"></div>

新版
<h1 class="animate__animated animate__bounce">An animated element</h1>
```

网址：

https://animate.style/

https://www.dowebok.com/demo/2014/98/



#### 3.动画和过渡区别

* 动画是一打开页面就运行，过渡必须触发才运行
* 动画可以指定多个状态，过渡只有两个状态



## 二、弹性盒布局

#### 1.概念

css3新增的一个布局方式，目的提供一种更加有效的方式来对容器中的子元素进行排列，分配空白空间，对齐方式

#### 2.弹性盒的特点

* 容器设置弹性盒后，里边的子元素在一行显示
* 在弹性盒里，子元素没有设置高度，高度和容器高度一致
* 在弹性盒里，子元素没有设置宽度，宽度由内容撑开
* 容器没有设置高度，高度由内容撑开
* 在弹性盒里，子元素的float,clear 以及  vertical-align无效

![image-20210115105811914](/image-20210115105811914.png)



#### 3.设置在容器上的样式

##### (1).形成弹性盒

```
display:flex;
display:inline-flex;
```

##### (2) 主轴方向

```
flex-direction: row;   默认   从左到右
flex-direction: row-reverse;  从右到左
flex-direction: column;      从上到下
flex-direction: column-reverse;  从下到上
```

##### (3)主轴对齐方式

```
justify-content: flex-start;   主轴起始端对齐
justify-content: flex-end; 主轴的结束端对齐
justify-content: center;  居中对齐
justify-content: space-around; 第一个项目和最后一个项目离容器的距离是，项目与项目之间距离的一半
justify-content: space-between;第一个项目和最后一个项目是紧挨着容器，项目与项目之间距离是等同的
justify-content: space-evenly;第一个项目和最后一个项目离容器的距离和，项目与项目之间距离是等同的
```

* 以主轴方向是从左到右为例
* justify-content: flex-start;  默认值

<img src="/image-20210115112538365.png" alt="image-20210115112538365" style="zoom:50%;" />

* justify-content: flex-end;

<img src="/image-20210115112604076.png" alt="image-20210115112604076" style="zoom:50%;" />

*  justify-content: center; 

  <img src="/image-20210115113012144.png" alt="image-20210115113012144" style="zoom:50%;" />

* justify-content: space-around;

  <img src="/image-20210115112630239.png" alt="image-20210115112630239" style="zoom:50%;" />

* justify-content: space-between

<img src="/image-20210115112654611.png" alt="image-20210115112654611" style="zoom:50%;" />

* justify-content: space-evenly;

<img src="/image-20210115112713964-1610715086733.png" alt="image-20210115112713964" style="zoom:50%;" />

##### (4)交叉轴对齐方式

```
align-items: stretch;   默认，项目未设置高度时，高度和容器高度一致
align-items: flex-start; 交叉轴的起始端对齐
align-items: flex-end;  交叉轴的终点对齐
align-items: center;   居中
align-items: baseline; 基线对齐
```



##### (5) 一行放不下，是否换行

```
flex-wrap: nowrap;  默认 ， 不换行
flex-wrap: wrap;   换行
flex-wrap: wrap-reverse; 换行-反向
```



##### (6) 多行的对齐方式

```
            align-content: flex-start;
            align-content: flex-end;
            align-content: center;
            align-content: space-around;
            align-content: space-between;
```

* align-content: flex-start;

<img src="/image-20210115135610539-1610715311913-1610715317515-1610715340417.png" alt="image-20210115135610539" style="zoom:50%;" />

* align-content: flex-end;

<img src="/image-20210115135632062.png" alt="image-20210115135632062" style="zoom:50%;" />

* align-content: center;

<img src="/image-20210115135652898-1610715442466.png" alt="image-20210115135652898" style="zoom:50%;" />

* align-content: space-around;

<img src="/image-20210115135715387.png" alt="image-20210115135715387" style="zoom:50%;" />

* align-content: space-between;

<img src="/image-20210115135737770.png" alt="image-20210115135737770" style="zoom:50%;" />

#### 4.设置在项目上的样式

##### (1) 改变项目的顺序

```
order:4;    值越小越靠前
```

##### (2)某个项目交叉轴的对齐方式

```
align-self:center;   值和align-items值一样
```

##### (3) 设置每个项目分配的空白空间

* 放大项目， 项目总宽 <  容器宽

  ```
  flex-grow: 2;
  ```

##### (4) 设置项目放不下时是否压缩

```
 flex-shrink: 1;   1默认值，压缩    0 不压缩
```

##### (5)每个项目所占份数

```
flex: 3;
```



## 三 calc函数

```
width: calc(100px + 50px * 2);
width: calc(100% - 400px);
```

* 注意：运算符左右得加空格
* 可以计算  +  -  *  /



## 四.less

#### 1.概念

CSS 预处理器定义了一种新的语言，其基本思想是，用一种专门的编程语言，为 CSS 增加了一些编程的特性，将 CSS 作为目标生成文件，然后开发者就只要使用这种语言进行编码工作, 

注意：引入html页面中的 得是生成的css文件

#### 2.好处

* 结构清晰，便于扩展，适应性强，可读性强
* 方便避免浏览器私有语法的差异
* 可以实现多重继承
* 完全兼容css代码
* 减少重复的机械劳动，便于维护



#### 3.语法

##### （1）注释

```
// less注释  不会编译到css文件中
/*注释可编译到css文件中*/
```

##### （2）变量

```
@变量名：值；
```

![image-20210115152057942](/image-20210115152057942-1610715784649.png)

* 变量是用在值上，直接@变量名
* 变量是用在样式名上，用时需要  @{变量名}

##### （3）嵌套

* & 表示的是当前层的标签

  ![image-20210115154624641](/image-20210115154624641.png)

##### （4）混入

* 简单混入

  ![image-20210115160431080](/image-20210115160431080.png)

* 带一个变量的混入

  ![image-20210115160514957](/image-20210115160514957.png)

* 带有多个变量的混入

  ![image-20210115160554339](/image-20210115160554339.png)

* 变量带有默认值的混入

  ![image-20210115160624616](/image-20210115160624616.png)

* 多个变量有默认值，只给其中一个变量传值

  ![image-20210115160656838](/image-20210115160656838.png)

*  @arguments

  * 代表多个变量，多个变量中间是空格隔开的

  ![image-20210115160732592](/image-20210115160732592.png)

##### （5）继承

![image-20210115165442828](/image-20210115165442828.png)

##### （6）值可计算

![image-20210115165515912](/image-20210115165515912.png)

##### （7）引入外部文件

![image-20210115165557148](/image-20210115165557148.png)