## 一、视口

* 布局视口   移动端的viewport ，  设计稿宽度   ， 一般是宽于浏览器屏幕的
* 视觉视口   浏览器屏幕宽
* 理想视口  布局视口等于视觉视口

```
 <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0,user-scalable=no" >
```

* width=device-width    布局视口宽等于设备宽
* user-scalable=no  用户是否能缩放页面    no    yes
* initial-scale=1.0  页面初始时的大小
* maximum-scable=1.0    能够缩放的最大值
* minimum-scable=1.0   能够缩放的最小值



## 二、移动端布局

#### 1.流式布局（了解）

* 宽度百分比，高度固定

#### 2.rem布局

* rem :  相对于根标签字体大小的倍数

* 步骤：
  * 设置viewport视口
  * 动态计算html标签的font-size值，  引入js文件
  * 把单位换成rem

#### 3.vw布局（了解）

* vw  视口单位，  将屏幕宽度分成100份    1vw  = 1%屏幕
* vh  视口单位， 将屏幕高度分成100份 



#### 4.vw+rem布局

```
  <style>
        html{
            font-size: 13.333333vw;
        }
        .box{
            width: 1rem;
            height: 1rem;
            background-color: red;
        }
    </style>
```

