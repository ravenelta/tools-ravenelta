---
typora-root-url: img
---

## 一、过渡

* 参与过渡样式

  *  多个值中间用逗号隔开，不写默认all

    ```
    transition-property: width , height ;
    transition-property: all;
    ```

* 过渡时间

  * 单位 s  ms 
  * 多个值中间用逗号隔开， 多个过渡时间是和多个参与过渡样式是一一对应

  ```
   transition-duration: 1s , 3s;
  ```

* 运行速度

  * linear  匀速      默认值 ease

  ```
   transition-timing-function: linear;
  ```

* 延迟时间

  *  单位 ：s  ms

  ```
   transition-delay: 1s;
  ```

*  复合写法

  * 过渡时间必写， 其他可省略不写

  ```
  transition: width 1s linear 1s , height 3s ease-in  2s;
  transition:  width 1s linear 1s; 
  ```

* 过渡效果如果放到盒子上，鼠标移入移出都有过渡效果，如果放到hover上，只有鼠标移入时有过渡效果





## 二、2d转换

#### 1.位移

```
            transform: translate(100px);   一个值，表示x轴位置
            transform: translate(100px,100px);  两个值：x轴位置  ， y轴位置
            transform: translateX(100px); x轴位置
            transform: translatey(100px); y轴位置
```

* 值可为负值

#### 2.缩放

```
            transform: scale(1.5); 一个值，x轴y轴同时缩放
            transform: scale(1.5,0.6); 两个值 ： x轴缩放，y轴缩放
            transform: scaleX(1.5);  x轴缩放
            transform: scaley(0.6);  y轴缩放
```

* 值： 1 原来大小     大于1 放大       0-1 缩小    0 缩小到没有     小于0  翻转过来缩放



#### 3.旋转

```
transform: rotate(40deg);
```

* 单位  deg  度数
* 正值，顺时针旋转，  负值，逆时针旋转



#### 4.倾斜

```
           transform: skew(30deg);    x轴倾斜
           transform: skew(30deg,30deg); x轴倾斜 ， y轴倾斜
           transform: skewX(30deg);x轴倾斜
           transform: skewy(30deg);y轴倾斜
```

* 值可以为负值



#### 5.复合写法

```
 transform: scale(1.2) translate(300px,300px) skew(30deg,20deg) rotate(30deg) ;
```

* 多个值之间用空格隔开
* 书写顺序不同，显示效果不同



#### 6.改变基准点

```
 transform-origin: 0px 0px; 两个值，x轴位置，y轴位置
 transform-origin: 100%;    一个值表示x轴位置，y轴默认是居中
 transform-origin: right bottom;
```

* 值：   px    %    关键词（right left top bottom  center)



## 三、3d转换

#### 1.景深

* 让元素有近大远小的效果
* 合适的取值范围  500px-1000px
* 给父元素设置景深，里边的子元素有近大远小效果

```
perspective: 800px;
```



#### 2.旋转

```
transform: rotateX(-40deg);   在右边看，正值是顺时针旋转，负值是逆时针旋转
transform: rotateY(40deg);   在下边看，正值是顺时针旋转，负值是逆时针旋转
transform:rotateZ(30deg) ;

transform: rotatex(40deg)  rotatey(40deg) rotateZ(40deg);
transform: rotate3d(1,0,0,40deg);
		 前三个值分别表示x轴  y轴 z轴是否旋转（0 表示不旋转  1表示顺时针旋转，-1表示逆时针旋转）
		 第四个值表示旋转的度数
```



#### 3.位移

```
transform:translateX(100px) translateY(100px) translateZ(300px);
transform: translate3d(100px,100px,200px);  三个值分别表示，x轴，y轴，z轴
```



#### 4.缩放

```
transform: scaleZ(3);
transform: scaleX(1.2) scaleY(1.3) scaleZ(1.2);
transform: scale3d(1.2,1.3,1.2);  三个值分别表示，x轴，y轴，z轴
```



#### 5.3d空间

* 最大盒子设置景深
* 给第二层盒子设置 transform-style: preserve-3d;
* 第三层盒子才存在于3d空间内
* 注意：transform-style不能和overflow一起使用

```
 transform-style: preserve-3d;
```



## 四、动画

#### 1.定义动画

```
 @keyframes dong{
            0%{
                width: 100px;
                height: 100px;
            }
            50%{
                width: 300px;
                height: 100px;
            }
            100%{
                width: 300px;
                height: 300px;
            }
        }
        
        
         @keyframes change{  
            from{
                width: 100px;
                height: 100px;
            }
            to{
                width: 300px;
                height: 300px;
            }
        }
```

* from... to...  等同于  0%...   100%....

  

#### 2.应用动画

```
 			/* 指定动画名 */
            animation-name: change;
            /* 动画运行时间 */
            animation-duration: 2s;
            动画运行速度
            animation-timing-function: linear;
            动画的等待时间
            animation-delay: 2s;
            /* 动画运行次数 */
            animation-iteration-count: 3;
            /* animation-iteration-count: infinite;  无限循环运行 */
            /* 动画运行方向 */
            animation-direction: alternate;  有方向运行    alternate-reverse
            
            
            动画的状态
            animation-fill-mode: none;
```

![](/3 (2).png)

#### 3.复合写法

```
 animation: name duration timing-function delay iteration-count direction fill-mode;
  animation: dong  3s  linear  2s  infinite  alternate forwards;
```

* 动画名和动画运行时间是必写的，其他可省略不写



#### 4.动画的运行状态

```
animation-play-state: paused;  暂停状态
                     running   运行状态
```

