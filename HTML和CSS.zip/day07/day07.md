## 一、精灵图   （雪碧图） css sprites

* 将页面中一些小的背景图片整合到一张大图上，通过background-image   background-position  background-repeat 进行背景定位， backgound-position 可以设置精确的数字将背景图定位到想要的位置

#### 1.优点

* 减少http请求
* 减少命名困扰
* 更换整体风格方便

#### 2.缺点

* 需要整合图片，需要背景定位
* 更换一个小图标时，所有小图标都要换



## 二、小箭头

```
 <style>
        .box{
            width: 100px;
            height: 100px;
            background-color: red;
            position: relative;
            overflow: hidden;
        }
        .one{
            width: 0px;
            height: 0px;
            border-width: 50px 0px 50px 50px;
            border-style: solid;
            border-color: transparent  transparent transparent yellow;
        }
        .two{
            width: 0px;
            height: 0px;
            border-width: 50px 0px 50px 50px;
            border-style: solid;
            border-color: transparent  transparent transparent red;

            position: absolute;
            top: 0px;
            left: -10px;

        }
    </style>
    
    
    html:
    
     <div class="box">
        <div class="one"></div>
        <div class="two"></div>
     </div>
```



## 三、滑动门

* 实现 特殊形状的背景能够自适应内容的长度
* 技术点： 背景定位   和    padding

```
 		.nav li{
            float: left;
        }

        .nav span{
            height: 33px;
            line-height: 33px;
            display: block;
            background: url(./img/lTcb_ve.png) right;
            padding-right: 10px;
        }
        .nav a{
            display: block;
            background: url(./img/lTcb_ve.png) ;
            color: #fff;
            padding-left: 10px;
        }
        
        
html:
     <ul class="nav">
        <li>
            <a href="#">
                <span>首页</span>
            </a>
        </li>
     </ul>
```



## 四、文本超出显示省略号

#### 1.单行文本超出显示省略号

```
			/* 强制不换行 */
            white-space: nowrap;
            /* 溢出隐藏 */
            overflow: hidden;
            /* 文本超出显示省略号 */
            text-overflow: ellipsis;
```

#### 2.多行文本超出显示省略号

* 第一种

```
			/* 变成弹性盒 */
            display: -webkit-box;
            /* 主轴方向是垂直 */
            -webkit-box-orient: vertical;
            /* 显示几行后出现省略号 */
            -webkit-line-clamp: 3;
            /* 溢出隐藏 */
            overflow: hidden;
```

* 第二种

  * 设置行高，盒子高度刚好是要显示行的倍数
  * 通过伪元素添加省略号，定位到盒子的右下角

  ```
   	.box2{
              width: 200px;
              background-color: green;
              margin-top: 50px;
  
              line-height: 25px;
              height: 50px;
              overflow: hidden;
              position: relative;
          }
          .box2:after{
              content: '...';
              position: absolute;
              bottom: 3px;
              right: 8px;
              padding: 2px;
              background: green;
          }
  ```



## 五、表单

#### 1.表单相关标签

* input  内联块标签

* form    块标签

* label   点击文字能够选中相对应的单选框和复选框

  ```
  <input type="radio" id="boy" name="sex" value="boy">   
  <label for="boy">男</label>   
  ```

* select  下拉列表    和option是固定搭配

  ```
   			<select name="address"  size="2">
                   <option value="beijing">北京</option>
                   <option value="shanghai">上海</option>
                   <option value="guang">广州</option>
                   <option value="nan" selected>南京</option>
               </select>
  ```

* textarea  文本域，常用在内容较多的情况

  ```
   <textarea name="msg" ></textarea>
  ```

  

#### 2.表单相关属性

##### （1）form标签上属性

* action   用来指定提交地址
* method   用来指定提交方式，默认get     post
  * get和post区别（了解）
    * get 提交的内容在url地址上，不安全， 长度有限制
    * post 提交的内容实在请求头里，相对安全，长度相对较长

##### （2）input标签上属性

* type   指定表单类型

  * text   文本框
  * password   密码框
  * submit    提交按钮
  * radio   单选按钮
    * checked   默认选中项
    * 单选里的name值必须设置一样才能实现单选
    * 设置默认值 ，提交时才有相对应的内容
  * checkbox   复选框
    * checked  默认选中项
    * 设置默认值 ，提交时才有相对应的内容
  * file   上传文件
  * image   以图片形式提交
    * src属性指定图片路径

  * reset  重置按钮   
    * 按钮上文字可通过value修改
  * button  普通按钮

* name   指定名字，如果表单需要提交就必须设置name属性

* placeholder   设置提示信息

* value    设置默认值

* readonly   只读   ， 可提交

* disabled   禁用，不可提交

* maxlength   限定输入框内容的最大长度

* minlength   限定输入框内容的最小长度

##### （3）select标签上属性   

* name   
* size   指定页面中要显示几条信息

##### （4）option 标签上属性

* value  默认值
* selected   默认选中项



## 六、使用特殊字体

```
 	@font-face {
            font-family: 'fire';   给本地字体起名字
            src: url(./汉仪火柴体简.TTF);  引入本地字体
        }

        .box{
            font-size: 50px;
            font-family: 'fire';   使用本地字体
        }
```

