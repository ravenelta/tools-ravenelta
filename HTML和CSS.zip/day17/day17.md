## 一、响应式

#### 1.概念

一个网站能够适配多个终端，实现在不同屏幕分辨率的终端上都能有很好的显示效果，其原理使用媒体查询检测不同终端屏幕的大小，来显示不同的布局

#### 2.优缺点

* 优点
  * 减少工作量， 设计，代码，内容只需要一份，多出来的是css和js的一些改变
  * 节省时间
  * 每个设备都能有很好的效果
* 缺点
  * 会多加载一些css和js
  * 不能特别精确的定位
  * 老版本兼容性不好



## 二、常用设备划分

* 大屏    台式           >1200px
* 中屏    笔记本     1200px - 992px
* 小屏     ipad        992px - 768px
* 超小屏   手机    < 768px



## 三、pc端优先和移动端优先

#### 1.pc端优先

* 先写大屏的布局，再通过媒体查询适配小屏布局

  ```
   @media screen  and (max-width:1200px) {
              div{
                  width: 25%;
              }
          }
  
          @media screen and (max-width:992px){
              div{
                  width: 33.3333%;
              }
          }
  
          @media screen and (max-width:768px){
              div{
                  width: 50%;
              }
          }
  ```

#### 2.移动端优先

* 先写小屏的布局，再通过媒体查询适配大屏布局

```
  @media screen and (min-width:768px){
            div{
                width: 33.33333%;
            }
        }


        @media screen and (min-width:992px){
            div{
                width: 25%;
            }
        }

        @media screen and (min-width:1200px){
            div{
                width: 20%;
            }
        }
```



## 四、响应式里的文字和图片

* 图片：  设置一个百分比的宽度
* 背景图：通过background-size指定大小
* 文字： 用rem 或  em 单位



## 五、技术要点

1.媒体查询

2.meta设置

* 视口设置

  ```
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  ```

* 兼容媒体查询

  IE8及更早版本的浏览器中不支持媒体查询，需要使用media-queries.js增加IE对媒体查询的支持：

  ```
   <!--[if lt IE 9]>
     <script src="https://cdn.bootcss.com/livingston-css3-mediaqueries-js/1.0.0/css3-mediaqueries.js"></script>
    <![endif]-->
  ```

* 调用高版本浏览器

  ```
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  ```

  

* 兼容不支持viewport的设备

  ```
  <meta name="HandheldFriendly" content="true">
  ```

  