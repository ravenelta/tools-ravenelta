---
typora-root-url: img
typora-copy-images-to: img
---

## 一、文字样式 （可继承）

* 继承来样式的优先级没有自己本身样式优先级高

#### 1.字体大小   font-size

* 默认字体大小 16px
* 浏览器支持最小字体是12px

#### 2.行高  line-height

* 小技巧： 行高和盒子高度一致时，可以实现单行文字垂直居中

#### 3.是否倾斜

```
font-style: italic | normal (不倾斜)
```

#### 4.是否加粗

```
 font-weight: bold |  normal(不加粗)  | (100-900, 100-549不加粗，550以上是加粗)
```

#### 5.字体

```
font-family: '楷体';
font-family: '楷体' , '黑体';
```

* 安全字体： 微软雅黑   黑体  楷体  宋体
* 可指定多个字体，中间用逗号隔开，首先使用第一个字体，如果用户电脑上没有，就采用第二个字体，以此类推

#### 6.复合写法

```
font: italic bold 30px/40px '楷体' ;
	  是否倾斜  是否加粗   字体大小/行高  字体；
```

* 字体大小 和 字体 是必须写的，其他可省略不写



## 二、文本样式（可继承）

#### 1.文字颜色  color

* a标签不能继承父元素的文字颜色，必须选中它自己设置color才行

#### 2.文字水平对齐方式

```
text-align: left(默认) | center  |  right   |  justify(两端对齐)
```

* 给父元素设置text-align时，可以改变父元素里边的**内联标签**和**内联块标签**的水平对齐方式

#### 3.首行缩进

```
text-indent: 2em;
```

* em  单位： 当前字体大小的倍数

#### 4.文本装饰

```
text-decoration: underline;   下划线
text-decoration: overline;    上划线
text-decoration: line-through;  中划线
text-decoration: underline dashed（虚线） red;  线条位置   线条样式  线条颜色
text-decoration: underline dotted red;  点状线
text-decoration: underline double red;  双实线
text-decoration: underline wavy red;   波浪线
text-decoration: underline solid red;   实线（默认）
```

```
text-decoration: none;  取消默认文本装饰
```



## 三、文本样式-扩展（了解）

#### 1.word-wrap: break-word;

如果英文单词一行放不下，先换行显示，换行放不下就再换行

![image-20201230142616485](/image-20201230142616485-1616208210624.png)

#### 2.word-break: break-all;

如果英文单词一行放不下，这一行能显示多少就显示多少，放不下的再换行

![image-20201230142719861](/image-20201230142719861.png)

#### 3.white-space: nowrap;

强制不换行

![image-20201230142753552](/image-20201230142753552.png)

#### 4.letter-spacing: 30px;

* 字母与字母之间的距离

![image-20201230143017925](/image-20201230143017925.png)

#### 5.word-spacing:30px;

* 词与词之间的空隙

  ![image-20201230143101570](/image-20201230143101570.png)



## 四、颜色和单位

#### 1.颜色表达方式

* 英文单词
* 十六进制（0-9 a-f)， #加六位十六进制数  
  * 前两位表示红色占比，中间两位表示绿色占比 ， 后两位表示蓝色占比
  * 如果两位两位的值是一样的，可以省略一个     eg:  #ff0000  =  #f00
* rgb(255,0,0)   r表示red   g表示green   b表示blue    取值 0 - 255
* rgba(255,0,0,0.5)   a表示alpha   颜色的透明度  取值0-1    1表示完全不透明  0 表示完全透明
* transparent   透明    背景色默认值就是透明



#### 2.单位

* px  固定单位  像素    -----  pc端页面
* em   相对于当前盒子字体大小倍数  ----- 首行缩进
* rem  相对于根标签（html标签）字体大小倍数  ----    移动端页面
* %     相对于父元素的百分比   ----   响应式页面





## 五、边框线

#### 1.第一种写法（了解）

```
border-top-width: 5px;
border-top-style: solid;
border-top-color: pink;

border-left-width: 10px;
border-left-style: dashed;
border-left-color: green;
```



#### 2.第二种写法

* 线条样式的值：  solid(实线)    dotted（点状线）   double(双实线)   dashed(虚线)

```
border-top: 10px dotted  blue;      
border-right: 10px double  orange;
border-bottom: 10px solid  red;
border-left: 10px dashed  skyblue;
```



#### 3.第三种写法

```
border-width: 10px  30px;    边框粗细
border-style: solid dotted  dashed;   边框样式
border-color: orange green  skyblue  red;  边框颜色
```

* 值的个数
  * 一个值：  四周
  * 两个值： 上下    左右
  * 三个值： 上    左右    下
  * 四个值： 上    右     下    左  （从上边开始 ， 顺时针绕一圈）



#### 4.第四种写法

```
border: 10px dotted  orange;  //粗细  样式  颜色
 
 
border-right: none;  取消某条边框线
border-right: 0;
```





## 六、内边距

* 边框线到内容的距离

#### 1.第一种写法

```
padding-left: 100px;
padding-top: 50px;
padding-right: 100px;
padding-bottom: 50px;
```



#### 2.第二种写法

```
 padding: 50px;
```

值的个数

* 一个值：  四周
* 两个值： 上下    左右
* 三个值： 上    左右    下
* 四个值： 上    右     下    左  （从上边开始 ， 顺时针绕一圈）





## 七、ps常用工具

#### 1.吸取颜色

​	![image-20201230170535039](/image-20201230170535039.png)

#### 2.量大小

![image-20201230170600134](/image-20201230170600134.png)

* 修改选区的起始位置： 按着鼠标左键不松手的前提下，按空格键挪动选区位置
* 编辑   ---》  首选项   --》  单位与标尺   ---》  像素



#### 3.切图

​	![image-20201230170906313](/image-20201230170906313.png)

* 通过切片工具选中图，alt+shift+ctrl+s  保存     或者     文件   ---》 存储为web所用格式

#### 4.改变画布大小

alt键  加鼠标滚轮