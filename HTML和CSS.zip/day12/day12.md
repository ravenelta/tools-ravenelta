## 一、css3新特性

* 选择器
* 背景样式
* 边框样式
* 文本样式
* 2d / 3d转换
* 动画
* 多列布局
* 弹性盒布局
* 用户界面



## 二、浏览器私有前缀

* 谷歌         blink           -webkit-
* safari      webkit        -webkit-
* 欧朋      blink              -o-
* ie         trident            -ms-
* 火狐     gecko             -moz-



## 三、渐进增强和优雅降级（了解）

* 渐进增强 progressive enhancement：针对低版本浏览器进行构建页面，保证最基本的功能，然后再针对

高级浏览器进行效果、交互等改进和追加功能达到更好的用户体验。

* 优雅降级 graceful degradation：一开始就构建完整的功能，然后再针对低版本浏览器进行兼容。



## 四、阴影

#### 1.盒子阴影

```
box-shadow: 5px 5px 10px 5px blue inset;
box-shadow: 5px 5px 10px 5px blue inset , 0px 0px 10px 5px green;  多个阴影，中间用逗号隔开
```

* 第一个值：  阴影x轴位置   ， 必写，  可为负值
* 第二个值： 阴影y轴位置， 必写， 可为负值
* 第三个值： 阴影的模糊值， 省略默认值为0   , 不能为负值
* 第四个值： 阴影大小，省略默认值为0 ,     >0   比当前盒子大      0   当前盒子大小   <0   比当前盒子小
* 第五个值： 阴影颜色，默认黑色
* 第六个值：是否内阴影， 不写默认为外阴影



#### 2.文字阴影

```
 text-shadow: 5px 5px 5px blue ,  -5px -5px 5px green ;
```

* 第一个值：  阴影x轴位置   ， 必写，  可为负值
* 第二个值： 阴影y轴位置， 必写， 可为负值
* 第三个值： 阴影的模糊值， 省略默认值为0   , 不能为负值
* 第四个值： 阴影颜色，默认是文字的颜色
* 多个阴影中间用逗号隔开



## 五、背景相关

#### 1.背景大小

```
            background-size: 50px auto;
            background-size: 100px 200px;
            background-size: 50% 50%;
            background-size: cover;
            background-size: contain;
```

* 一个值，表示的是宽度，高度默认auto
* 两个值， 宽度     高度
* 值：  px      %      auto       
  * cover     在图片保持不变形的情况下，能够完整的覆盖整个盒子，有可能一部分背景图显示不出来
  * contain   在图片保持不变形的情况下，能够最大的显示完整的背景图，有可能盒子的一部分没有背景图

#### 2.背景定位区域

```
            background-origin: padding-box;  padding区域内   (默认值)
            background-origin: content-box;   内容区域
            background-origin: border-box;	 边框区域
```



#### 3.背景剪裁区域

```

            background-clip: border-box;  边框区域  （默认值）
            background-clip: padding-box; padding区域内 
            background-clip: content-box;  内容区域
```



#### 4.复合写

```
  background: blue  url(./1.png) repeat  50px 50px/100px 200px content-box padding-box;
                                          背景定位/ 背景大小      背景定位区域   背景裁切区域
```

#### 5.多背景

```
background: url(./1.png) no-repeat , url(./2.png) no-repeat 50px 50px;
```

* 多背景中间用逗号隔开
* 先写的在前，后写的在后



## 六、渐变

#### 1.线性渐变

* 注意，私有前缀是加在   -webkit-linear-gradient
* 颜色，至少要有两个，颜色值之间用逗号隔开

```
 background: -webkit-linear-gradient(red,blue);
 
 background: linear-gradient(red 0px,red 150px,yellow);
 颜色后空格隔开再写一个值，该值表示的是当前颜色的范围
 单位： px  %
 
 
background: linear-gradient(to right top, red,blue);
background: linear-gradient(to right, red,blue);
  在颜色值的最前边可以通过 to 加关键词，改变颜色的方向
  
 
background: linear-gradient(90deg,red,blue);
    可通过度数设置颜色的方向
```



#### 2.径向渐变

```
 background: radial-gradient(red,blue,yellow);
 
background: radial-gradient(red 0px, red 50px,blue 50px);
颜色后空格隔开再写一个值，该值表示的是当前颜色的范围

background: radial-gradient(at 0px 0px, red 0px, red 50px,blue 50px);
background: radial-gradient(at bottom right, red 0px, red 50px,blue 50px);
background: radial-gradient(at 20% 20%, red 0px, red 50px,blue 50px);
background: radial-gradient( circle at 50px 100px, red 0px, red 50px,blue 50px);
at 加 px  或  关键词  或  %  改变圆心位置
circle at    始终保持正圆

```

#### 3.重复性的线性渐变和径向渐变

```
 background: repeating-linear-gradient(red 0px , red 50px , blue 50px ,blue 100px);
 
 background: repeating-radial-gradient(red 0px , red 50px , blue 50px ,blue 100px);
```

## 七、用户界面

#### 1.box-sizing

```
box-sizing: boder-box;  怪异盒模型
box-sizing:content-box; 标准盒模型（默认值）
```

#### 2.用户改变元素大小

```
            resize: horizontal; 可改变宽度
            resize: vertical;   可改变高度
            resize: both;      可改变宽高
            resize:none;      禁止改变宽高
```

* 必须配合overflow： hidden | auto | scroll 使用



## 八、多列布局

```
column-count: 3;    设置栏数 （栏数和每栏的宽度，只能设置其一）
column-width: 300px;  设置每栏的宽度
column-gap: 50px;   设置栏与栏之间的距离
column-rule: 2px solid red;  栏与栏之间的分割线


 column-span: all;  设置给标题的，   1 标题是在第一栏显示（默认值）  all(横跨所有栏显示)
```



## 九、选择器

#### 1.属性选择器

```
 		div[class^='box1']{   以box1开头 }

        div[class$='box1']{   以box1结尾 }
        
        div[class*='box1']{  包含box1 }
```



#### 2.状态伪类选择器

```
        input:focus{   聚焦状态时选中  css2
            background-color: red;
        }
        input:disabled{  禁用状态时选中
            background-color: green;
        }
        input:enabled{  可用状态下选中
            background-color: pink;
        }
        input:checked{  选中状态下
            width: 200px;
            height: 200px;
        }
```



#### 3.结构伪类选择器

```

        .box p:first-child  若box里第一个标签是p标签时选中
        .box p:first-of-type  选中的是box里第一个p标签

        .box p:last-child  若box里最后一个标签是p标签时选中
        .box p:last-of-type  选中的是box里最后一个p标签
        
        .box p:nth-child(1)   如果box里第1个标签是p标签时选中
            odd  奇数   even 偶数  2n  偶数   2n-1  奇数   -n+3 前三个   n+3 从第3个开始都选中
        .box p:nth-of-type(2) 选中的是box里第2个p标签
        
        .box p:nth-last-child(3) 如果box里倒着数第三个标签是p标签时选中
        .box p:nth-last-of-type(3) 选中的是box里倒着数第三个p标签
        
        .box p:only-child  选中的是box里有且只有一个p标签
        .box p:only-of-type 选中的是box里只有一个p标签，但是可以有其他类型的标签
```



