## 一、外边距

* 盒子边框线以外的距离
* 值可为负值，上外边距和左外边距，影响的是自身的位置； 右外边距和下外边距影响的是该盒子右边和下边盒子的位置

#### 1.第一种写法

```javascript
margin-bottom: 50px;
margin-left: 50px;
margin-top: 50px;
margin-right: 50px;
```



#### 2.第二种写法

```
margin:30px;
```

* 可为多个值
  * 一个值：  四周
  * 两个值： 上下    左右
  * 三个值： 上    左右    下
  * 四个值： 上    右     下    左  （从上边开始 ， 顺时针绕一圈）



```
margin: 0px auto;
```

* 左右外边距设置为auto,可以使有固定宽度的块标签水平居中



## 二、margin存在问题

#### 1.塌陷问题

* 父元素里第一个子元素设置margin-top, 会传递给父元素，带着父元素向下

* 解决办法
  * 给父元素设置padding-top
  * 给父元素设置border-top
  * 给父元素设置overflow:hidden  形成私有区域
  * 避免使用margin-top

#### 2.重叠问题

* margin-top  和marign-bottom相遇时，取最大值

* 解决办法

  * 将其中一个盒子套一个大盒子，给大盒子设置overflow：hidden;形成私有区域

  * 避免使用

    

## 三、盒模型

* 盒子在浏览器中的占位,   每个标签都有盒模型
* 标准盒模型组成：  
  * 占位宽：  width   +   左右padding   +  左右border   +   左右margin 
  * 占位高：  height  +   上下padding   +  上下border   +   上下margin 		



* 怪异盒模型

  ```
  box-sizing: border-box;
  ```

  * 怪异盒模型组成 ：  width(包含padding  和  border)  +  margin



## 四、最大最小宽高

```javascript
            max-width: 300px;    盒子的宽度小于等于 300px
            min-width: 1000px;	 盒子的宽度大于等于 1000px
            max-height: 300px;
            min-height: 550px;
```





## 五、背景相关

#### 1.背景颜色

```
background-color: red;
```

* 默认背景色是透明的

#### 2.背景图片

```
 background-image: url(./3.png);
```

#### 3.背景图是否平铺

```
background-repeat: no-repeat;  不平铺
				 repeat  平铺（默认值）
				 repeat-x  x轴平铺
				 repeat-y  y轴平铺
```



#### 4.背景图定位

```
background-position: 50px;
background-position: right bottom;
background-position:100% 100%;
background-position: 50px bottom;
```

* 多个值：

  * 一个值： x轴位置   y轴默认居中

  * 两个值： x轴位置  y轴位置

  * 值可以为负值

  * 可为  具体px  |   关键字  （top  bottom  left  right  center)  |   百分比    |  混合写法

    

#### 5.背景图是否固定（了解）

```
background-attachment: fixed;
```

* 如果背景图固定，背景定位是相对于浏览器屏幕的



#### 6.复合写法

```
background: red url(./3.png)  no-repeat  right bottom  fixed;
		   颜色   图片         是否平铺          定位      是否固定
```

* 其中至少写背景色 或者  背景图片，其他可省略不写



## 六、进阶选择器

#### 1.后代选择器

```
 .box p{  }
```

* 选中的是box里所有的p标签， 不管嵌套多少层都能选中
* 中间用空格隔开

#### 2.子代选择器

```
.box>p{  }
```

* 选中的是box里一级子元素是p标签的
* 中间用尖角号隔开

#### 3.群组选择器 

```
 .p1 , .p3 , .box1 p{
            /* background-color: pink; */
        }
```

* 能同时选中多个标签，逗号隔开的是一个完整的选择器
* 中间用逗号隔开

#### 4.交集选择器 

```
 h3.p1{
            
        }
```

*  选中的是class名为p1 并且是h3标签



#### 5.相邻兄弟选择器

```
.p4+.p1{
            background-color: pink;
        }
```

* 选中的是p4下边紧挨着的class名为p1的标签
* 中间用加号隔开



#### 6.伪类选择器

```
     /* 访问前 */
        a:link{
            color: green;
        }
        /* 访问后 */
        a:visited{
            color: red;
        }
        

        /* 鼠标移入 */
        a:hover{
            color: orange;
        }

         /* 鼠标按下 */
         a:active{
            color: orchid;
        }
```

* 如果同时设置四个状态，需要注意书写顺序 ：   link  -->   visited  -->  hover  -->active
* 除a标签以外，其他的标签只有hover   和  active 



## 七、css三大特性

#### 1.层叠性

* 浏览器处理冲突的能力，一个相同的样式通过两个相同类型的选择器选中同一标签设置上，其中一个样式会被另一样式覆盖掉

#### 2.继承性

* 子元素能够应用父元素上的样式（文字样式和文本样式）

#### 3.优先级

* 权重    id--100   class--10  标签--1  *--0 
* 进阶选择器权重计算：通过加法计算
* 权重相同，选中同一标签，遵循就近原则
* 权重不同，选中同一标签，权重大的优先级高
* 权重不同，选中的标签不同，还是得遵循，继承来的样式优先级没有自己本身样式优先级高
* !important权重最大，可以盖过行间样式，但是还得遵循继承来的样式没有自身样式优先级高

