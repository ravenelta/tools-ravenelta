## 一、移动端特殊处理

#### 1.超小字体的处理

```
transform: scale(0.8);
transform-origin: top left;
```

#### 2.使用3d动画，可启用硬件加速（慎用，比较占内存）

```
transform:translate3d();
-webkit-transform:translate3d()
```

#### 3.部分安卓机出现圆角失效

```
background-clip:padding-box;
```

#### 4.部分机型的 placeholder文字居上

解决办法，不用行高，用padding-top挤



## 二、像素（了解）

#### 1.css像素(独立像素)

操作系统定义的像素单位

一般是和手机大小一致

iPhone 6/7/8 :  375 * 667

#### 2.设备像素（物理像素）

是真实存在的，设备一出厂就固定

iPhone 6/7/8 :  750 * 1334

#### 3.设备像素比   dpr

设备像素/css像素

window.devicePixelRatio

#### 4.高清屏

普通屏 /  pc端 ：    1css像素 = 1设备像素

高清屏     1css像素 = 2设置像素



## 三、媒体查询

#### 1.在link里限定条件

```
<link rel="stylesheet" href="./1.css" media="screen and (min-width:1000px)">
<link rel="stylesheet" href="./2.css" media="screen and (max-width:1000px) and (min-width:800px)">
<link rel="stylesheet" href="./3.css" media="screen and (max-width:800px)">
```

```
横屏
<link rel="stylesheet" href="./2.css" media="screen and (orientation:landscape)">
竖屏
<link rel="stylesheet" href="./3.css" media="screen and (orientation:portrait)">
```

#### 2.在css限定条件

```
  @media screen and (max-width:1000px) and (min-width: 800px){
            .box{
                background-color: yellow;
                column-count: 3;
            }
        }

        @media screen  and (max-width:800px){
            .box{
                background-color: pink;
                column-count: 2;
            }
        }

```



## 四、flexible +rem布局（了解）

