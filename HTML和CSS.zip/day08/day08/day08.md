## 一、自适应两栏布局

* 左边宽度固定，右边盒子宽度自适应
* 实现步骤
  * 结构： 左右两个盒子（左边盒子宽度固定，右边盒子宽度100%）
  * 左边盒子设置绝对定位
  * 右边盒子里的内容放到一个小盒子里，给该小盒子设置padding-left :  左盒子的宽度

```
 <style>
        .left{
            width: 300px;
            height: 300px;
            background-color: red;
            position: absolute;
        }
        .right{
            width: 100%;
            height: 320px;
            background-color: green;
        }
        .main{
            padding-left: 300px;
        }
    </style>
    
    
    <div class="box">
        <div class="left">左边内容</div>
        <div class="right">
            <div class="main">右边内容</div>
        </div>
    </div>
```



## 二、圣杯布局

* 自适应三栏布局，左右盒子宽度固定，中间盒子宽度自适应

* 步骤
  * 结构：  大盒子套三个小盒子（中 宽100% -   左 固定宽   -  右 固定宽）
  * 给三个小盒子加浮动
  * 左盒子加margin-left: -100%；  让左盒子挪到页面的最左边
  * 右盒子加margin-left: 负的自身宽度； 让右盒子挪到页面的最右边
  * 给大盒子设置padding: 0px  右盒子宽度   0px  左盒子宽度；
  * 左盒子加相对定位，left : 负的自身宽度
  * 右盒子加相对定位，left : 自身宽度
  * 给大盒子加min-width
  * 记得清楚浮动产生问题

```
 <style>
        .center{
            width: 100%;
            height: 320px;
            background-color: orange;
            float: left;
        }
        .left{
            width: 300px;
            height: 300px;
            background-color: pink;
            float: left;
            margin-left: -100%;
            position: relative;
            left: -300px;
        }
        .right{
            width: 200px;
            height: 300px;
            background-color: blue;
            float: left;
            margin-left: -200px;
            position: relative;
            left: 200px;
        }
        .box{
            padding: 0px 200px 0px 300px;
            min-width: 500px;
            overflow: hidden;
        }
    </style>
    
    
     <div class="box">
        <div class="center">中间内容</div>
        <div class="left">左边内容</div>
        <div class="right">右边内容</div>
    </div>
```



## 三、双飞翼布局

* 自适应三栏布局，左右盒子宽度固定，中间盒子宽度自适应
* 步骤
  * 结构：  大盒子套三个小盒子（中 宽100% -   左 固定宽   -  右 固定宽）
  * 给三个小盒子加浮动
  * 左盒子加margin-left: -100%；  让左盒子挪到页面的最左边
  * 右盒子加margin-left: 负的自身宽度； 让右盒子挪到页面的最右边
  * 给中间内容再套一个盒子，给该盒子设置padding: 0px  右盒子宽  0px  左盒子宽； 或 margin
  * 大盒子设置min-width
  * 记得清楚浮动产生问题

```
<style>
        .center{
            width: 100%;
            height: 320px;
            background-color: orange;
            float: left;
        }
        .left{
            width: 300px;
            height: 300px;
            background-color: pink;
            float: left;
            margin-left: -100%;
        }
        .right{
            width: 200px;
            height: 300px;
            background-color: blue;
            float: left;
            margin-left: -200px;
        }
        .main{
            padding: 0px 200px 0px 300px;
        }
        .box{
            min-width: 800px;
            overflow: hidden;
        }
    </style>
    
    
     <div class="box">
        <div class="center">
            <div class="main">中间盒子</div>
        </div>
        <div class="left">左边</div>
        <div class="right">右边</div>
    </div>
```



## 四、伪等高布局

* 改变其中一栏高度，其他几栏高度跟着改变
* 步骤
  * 结构：一个大盒子套三个小盒子 （小盒子不能设固定高度）
  * 给三个小盒子设置浮动
  * 给三个小盒子设置 padding-bottom:9999px
  * 给三个小盒子设置 margin-bottom:-9999px   
  * 给大盒子设置overflow:hidden(清除浮动    溢出隐藏)

```
  /* 
            占位高 =  height   +  padding  +  border +  margin
         */
        .left{
            width: 300px;
            background-color: red;
            float: left;
            padding-bottom: 9999px;
            margin-bottom: -9999px;
        }
        .center{
            width: 400px;
            background-color: green;
            float: left;
            padding-bottom: 9999px;
            margin-bottom: -9999px;
        }
        .right{
            width: 300px;
            background-color: blue;
            float: left;
            padding-bottom: 9999px;
            margin-bottom: -9999px;
        }
        .box{
            overflow: hidden;
        }


 <div class="box">
        <div class="left">左边</div>
        <div class="center">中间</div>
        <div class="right">右边内容</div>
    </div>
```

* 问题：如果某一栏加边框，不显示下边框
* 解决：  
  * 在该盒子里写一个盒子，设置宽高，让其相对于大盒子进行定位
  * 给该盒子写伪元素，设置宽高，让其相对于大盒子进行定位

```
 		.box{
            overflow: hidden;
            position: relative;
        }
        
        第一种
        /* .bian{
            width:310px;
            height: 5px;
            background-color: #000;
            position: absolute;
            bottom: 0px;
            left: 0px;
        } */
        
        第二种
         .left:after{
            content: '';
            display: block;
            width:310px;
            height: 5px;
            background-color: #000;
            position: absolute;
            bottom: 0px;
            left: 0px;
        }
        
         <div class="left">左边
            <!-- <div class="bian"></div> -->
        </div>
        <div class="center">中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间中间</div>
        <div class="right">右边内容</div>
        
```



## 五、真等高布局

* 步骤
  * 结构： 有几栏就套几个大盒子，里边放小盒子
  * 给小盒子设置浮动，给儿子清除浮动
  * 给爸爸设置margin-left: 左边盒子宽度;
  * 给儿子设置margin-left: 中间盒子宽度；
  * 给左盒子设置相对定位，left：负的  左盒宽+中盒宽
  * 给中盒子设置相对定位，left:负的 左盒宽+中盒宽
  * 给右盒子设置相对定位，left: 负的  左盒宽+中盒宽
  * 给爷爷设置overflow:hidden;

```
  <style>
        .grandpa{
            width: 900px;
            background-color: red;
            overflow: hidden;
        }
        .father{
            width: 100%;
            background-color: green;
            margin-left: 300px;
        }
        .son{
            width: 100%;
            background-color: blue;
            margin-left: 300px;
        }
        .left{
            width: 300px;
            float: left;
            position: relative;
            left: -600px;
        }
        .center{
            width: 300px;
            float: left;
            position: relative;
            left: -600px;
        }
        .right{
            width: 300px;
            float: left;
            position: relative;
            left: -600px;
        }
        .son:after{
            content: '';
            display: block;
            clear: both;

        }
    </style>
    
    
     <div class="grandpa">
        <div class="father">
            <div class="son">
                <div class="left">左边左边左边左边左边左边左边左边左边左边左边左边左边</div>
                <div class="center">中间中</div>
                <div class="right">右边</div>
            </div>
        </div>
    </div>
```



## 六、tdk

* t    页面标题   title标签

* d   页面描述   meta标签

* k   页面关键词  meta标签

  ```
      <title>Document</title>
      <meta name="description" content="这是一个小u商城网站">
      <meta name="keywords" content="商城，衣服，shopping,日用品">
  ```

  

## 七、标题前小图标

```
<link rel="icon" href="./img/bitbug_favicon.ico">
```

* 引入的图片类型是 ico的，可通过比特虫网站转换  ：http://www.bitbug.net/



## 八、浏览器屏幕宽小于有效区，超出部分会出现空白

* 给大盒子设置min-width:有效区宽度
* 给有效区也加一个背景色