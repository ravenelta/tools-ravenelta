## 一、网格布局

#### 1.形成网格布局

```
display:grid
display:inline-grid
```

#### 2.放在容器上的样式

##### （1）设置网格的行与列

```
grid-template-columns: 100px 200px 100px;  列
grid-template-rows: 100px 200px;     行
```

* 值：
  * px      %    fr(份数)
  * repeat(列数 ， 宽度)
  * 指定每条网格线的名字
  * auto   
  * minmax(最小值，最大值)

```
            grid-template-columns: 100px 200px 100px;
            grid-template-columns: 33.333%  33.333%  33.333% ;
            grid-template-columns: 1fr  2fr 1fr;
            grid-template-columns: repeat(3,33.333%);
            grid-template-columns: [c1]  100px  [c2] 200px [c3] 100px [c4];
            grid-template-columns: 200px  auto  200px ;
            grid-template-columns: 200px  minmax(400px,auto)  200px;
```

##### （2） 单元格空隙

```
grid-column-gap: 20px;   列与列之间空隙
grid-row-gap: 30px;行与行之间空隙
grid-gap: 20px 30px; 复合写法，第一个值：行与行空隙  列与列空隙
```

##### （3）设置单元格的名字

* 配合项目上的样式  grid-area

  ```
   grid-template-areas:   'a  b  c'
                          'd  e  f';
  ```

##### （4）项目的排列顺序

```
grid-auto-flow: row;  默认 先行
grid-auto-flow: column;   先列
grid-auto-flow: row dense; 尽量不出现空格
grid-auto-flow: column dense; 尽量不出现空格
```

##### （5） 项目中内容在单元格里的位置

```
 水平方向     justify-items: start;
            justify-items: end;
            justify-items:center;
            justify-items: stretch; （默认值，默认项目宽和单元格宽度一致）

垂直方向            align-items: stretch;（默认值，默认项目高和单元格高度一致）
            align-items: start;
            align-items: end;
            align-items: center;
            
            
  复合写法
     place-items: start  end;  垂直方向   水平方向
```



##### （6）项目在容器中的位置

```
水平方向		 	justify-content: start;
            justify-content: end;
            justify-content:center;
            justify-content:space-around;
            justify-content:space-between;
            justify-content:space-evenly;


垂直方向            align-content: start;
            align-content: end;
            align-content: center;
            align-content: space-around;
            align-content: space-between;
            align-content: space-evenly;

 复合写法           place-content: start center;  垂直方向  水平方向
```



#### 3.放在项目上的样式

##### （1）指定项目所在的网格线

```
纵向网格线       grid-column-start:c2 ; 
                grid-column-end: c3;

复合写法     grid-column: c2/c3;   起始网格线/结束网格线
             grid-column: 2/3;

横向网格线     grid-row-start: 2;
            grid-row-end: 3;

 复合写法     grid-row: 2/3; 起始网格线/结束网格线
```

##### （2）指定项目在哪个单元格

* 配合 容器上的 grid-template-areas  使用

```
grid-area:header;
```

##### （3）指定某个项目中内容在单元格的位置

```
 水平方向          justify-self: start;
            justify-self: end;
            justify-self:center;
            justify-self:stretch;

  垂直方向          align-self: stretch;
            align-self: start;
            align-self: end;
            align-self:center;

   复合写法         place-self: start end;  垂直方向   水平方向
```

