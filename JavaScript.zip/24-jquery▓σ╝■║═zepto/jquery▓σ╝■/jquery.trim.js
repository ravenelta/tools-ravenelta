;$(function(){
    $.extend({
        leftTrim:function(str){
            console.log(this===$);//$
            console.log(this===jQuery);//$
            var reg = /^\s+/;
            var str1 = str.replace(reg,"");
            return str1;
        },
        rightTrim:function(str){
            var reg = /\s+$/;
            var str1 = str.replace(reg,"");
            return str1;
        }
    });
});