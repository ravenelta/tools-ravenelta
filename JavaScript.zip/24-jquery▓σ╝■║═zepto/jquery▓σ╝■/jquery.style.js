;$(function(){
    $.fn.extend({
        style:function(){
            //如果用户只传入一个参数 有可能是想获取单个样式值 也可能想批量设置样式
            // console.log(this);
            //如果用户传入两个参数 证明用户想设置单个样式
            //使用arguments 来监测 用户传入了多少个实参
            if(arguments.length==1){
                if(typeof arguments[0]=="string"){
                    var sty = getComputedStyle(this[0])[arguments[0]];
                    return sty;
                }else{
                    for(var key in arguments[0]){
                        this[0].style[key] = arguments[0][key];
                    };
                };
            };
            if(arguments.length==2){
                this[0].style[arguments[0]] = arguments[1];
            };
        }
    });
});