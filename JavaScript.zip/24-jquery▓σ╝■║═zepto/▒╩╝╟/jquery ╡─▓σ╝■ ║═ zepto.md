# jquery 的插件 和 zepto

## jquery的插件

### 1.jquery插件的简单描述

```javascript
虽然jq很强大，但是有些方法还是没有给我们封装，所以我们要自己实现。为了公用，我们会把它做成插件的形式。
插件本身不直接对jq代码进行操作，而是间接对jq代码进行修改。
如果我们在使用的时候，某个功能没有，我们就可以自己开发一个插件来使用。
```

### 2.jquery插件的分类

```javascript
1.jquery的类级别插件
类级别插件的封装：
$.extend({
    插件的方法：function(){}，
    插件的方法2：function(){}，
	。。。。。
})
类级别插件的使用
类级别插件的方法类似于  ajax方法、extend方法 直接由$调用
写作：$.类级别插件方法()
为了能够让插件公用，因此我们应该把插件代码 单独写为一个js文件 在编写插件js文件的时候需要注意一下几点
	1.jquery插件的名字 应尽量命名为 jquery.插件名.js
	2.在编写插件的时候 一定要注意代码的严谨性 每一句代码结束的时候 都必须添加分号
	3.容错性处理 在整段插件代码前面 添加分号 防止压缩之后 代码出现问题
	4.由于jquery的插件 依赖于jquery来运行 因此 在使用的时候 一定要确保 先引入jquery 后引入插件
类级别插件的方法中 this 值为 jQuery===$


2.jquery的对象级别插件
对象级别插件的封装
$.fn.extend({
    对象级别插件方法名:function(){},
    对象级别插件方法名1:function(){},
    .....
})
对象级别插件的用法：jquery元素.对象级别插件方法名()
对象级别插件封装的规则 和 类级别插件完全一样
在对象级别插件的方法函数中 this 值为 调用当前方法的jquery元素

第三方插件：在百度搜索 jquery22 即可找到jquery插件库
```

## zepto

```javascript
1.定义：Zepto是一个轻量级的针对现代高级浏览器的JavaScript库， 它与jquery有着类似的api。 如果你会用jquery，那么你也会用zepto。
zepto的绝大部分方法和jquery是完全相同的 但有部分方法和jquery有小区别
zepto主要针对移动端应用 开发  库文件压缩后的大小 可以达到9.6k 极大限度上 节省了应用占用的内存

2.zepto的模块化
zepto是一个模块化的类库 为了将源代码尽可能的压缩 zepto将功能拆分成了多个模块 除了部分核心模块在源代码中内置，其余的模块 如果用户需要，这可以引用 如果用户不需要，这可以不引用

module	default	description
zepto	✔	核心模块；包含许多方法
event	✔	通过on()& off()处理事件
ajax	✔	XMLHttpRequest 和 JSONP 实用功能
form	✔	序列化 & 提交web表单
ie		✔	增加支持桌面的Internet Explorer 10+和Windows Phone 8。
detect		提供 $.os和 $.browser消息
fx			The animate()方法
fx_methods	以动画形式的 show, hide, toggle, 和 fade*()方法.
assets		实验性支持从DOM中移除image元素后清理iOS的内存。
data		一个全面的 data()方法, 能够在内存中存储任意对象。
deferred	提供 $.Deferredpromises API. 依赖"callbacks" 模块.
			当包含这个模块时候, $.ajax() 支持promise接口链式的回调。
callbacks	为"deferred"模块提供 $.Callbacks。
selector	实验性的支持 jQuery CSS 表达式 实用功能，比如 $('div:first')和 el.is(':visible')。
touch		在触摸设备上触发tap– 和 swipe– 相关事件。这适用于所有的`touch`(iOS, Android)和`pointer`事件				(Windows Phone)。
gesture		在触摸设备上触发 pinch 手势事件。
stack		提供 andSelf& end()链式调用方法
ios3		String.prototype.trim 和 Array.prototype.reduce 方法 (如果他们不存在) ，以兼容 iOS 3.x.


3.zepto 和 jquery的区别
获取元素大小
jquery：width/height、innerWidth/Height、outerWidth/Height、传true
zepto: width/height 代表元素自身宽高 + padding + border  没有innerWidth/Height 及 outerWidth/
Height
获取元素位置
jquery：offset、position
zepto：offset表示当前元素到可视窗口左侧和顶部的距离 多了两个属性 width 和 height
	  {left: 188, top: 180, width: 100, height: 100}
	  position表示当前元素到带定位父元素左侧和顶部的距离
      {top: 100, left: 100}

4.zepto的移动端事件
zepto 的pc端事件  是内置在源码中的 不需要引入任何外部模块
而移动端事件则需要使用 touch模块才可以激活
tap类事件 ： tap单击  singleTap单击  doubleTap双击 longTap长按
swipe类事件 ： swipe滑动  swipeUp上滑  swipeDown下滑  swipeLeft左滑  swipeRight右滑
```



## jquery补充

```javascript
jquery的两大核心
1.链式编程：jquery的方法可以在一行中连续调用
jquery元素.方法1().方法2()....
$("div").css({width:300,height:300,background:'red'}).animate({opacity:0.3},1000).animate({borderRadius:150},2000)
函数的返回值  就是 函数调用表达式的值
jquery元素.css() === css的返回值 === jquery元素.其他方法()
注意：jquery中的方法并不是任何方法 都可以使用链式编程调用的  所有对jquery元素进行操作的方法都可以链式调用， 而想要获取内容的方法 则不可链式调用  这种规则是jquery链式调用的原理导致的

链式调用的原理：在jquery中 所有操作jquery元素的方法函数 都会在其末尾 返回当前操作的jquery元素 因此可以继续使用返回值(当前操作的jquery元素) 调用其他方法   但所有获取内容 的方法 其返回值都是获取到的结果 不是jquery元素 因此不能继续调用其他方法

2.隐式迭代
在jquery中 获取jquery元素 得到的是一个伪数组 我们在给jquery元素添加事件、执行操作等功能的时候 不需要手动循环jquery元素伪数组，jquery会自动给我们循环 并给每一个元素都添加效果  这就是隐式迭代
隐式迭代很方便  但并不适用于 所有情况  如果我们需要使用循环的索引 就必须使用显式迭代($.each、jquery元素.each)
```



