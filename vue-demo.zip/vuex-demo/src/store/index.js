// 导入vuex
import Vuex from 'vuex'
import Vue from 'vue'

import axios from '../utils/http'
// 导入模块
import user from './modules/user'
import goods from './modules/goods'
// 注册
Vue.use(Vuex)
// 创建store对象
let store = new Vuex.Store({
    // 存储数据
    state:{
        username:'张飞',
        nickname:'哈哈哈',
        brandList:[],
    },
    // 类似于计算属性
    getters:{
        // state是系统自动注入的形参
        getUsername(state){
            return state.username + '~~'
        }
    },
    // 唯一改变state的方法
    mutations:{
        // state系统自动注入，代表存储的数据。data传入要改变的值
        setUsername(state,data) {
            state.username = data
        },
        setBrandList(state,list){
            state.brandList = list
        }
    },
    // 操作数据的异步方法，ajax
    actions:{
        // 上下文对象，里面有commit方法
        getBrandListAction(context){
            axios.get('/brandList').then(res=>{
                console.log(res.list)
                // 
                context.commit('setBrandList',res.list)
            })
        }
    },
    modules:{
        user,goods
    }
})

// 导出
export default store