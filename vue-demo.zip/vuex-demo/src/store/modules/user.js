export default {
    // 命名空间
    namespaced: true,
    state: {
        userList: [],
        usercount: 10
    },
    getters: {
        getUsercount(state) {
            return state.usercount + '个'
        }
    },
    mutations: {
        setUsercount(state, data) {
            state.usercount = data
        },
        setUserList(state,list){
            state.userList = list
        }
    },
    actions: {
        // context是系统自动注入的上下文对象，里面包含commit和dispatch 方法
        // context.commit()   {commit}
        // 结构
        getUserListAction({commit}) {
            let arr = [
                { id: 1, name: '张三', age: 20 },
                { id: 2, name: '李四', age: 20 },
                { id: 3, name: '王五', age: 20 },
            ]
            commit('setUserList',arr)
        }
    }
}