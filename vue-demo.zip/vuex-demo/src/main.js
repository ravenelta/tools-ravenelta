// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
// 导入store
import store from './store'
// 1.引入element-ui核心库
import ElementUI from 'element-ui';
// 2.引入element-ui样式表
import 'element-ui/lib/theme-chalk/index.css';
// 3.注册
Vue.use(ElementUI)

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  // 挂载
  store,
  components: { App },
  template: '<App/>'
})
