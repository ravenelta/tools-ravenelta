<template>
 <div class="goods">
     <h1>商品管理</h1>
     {{username}}
     {{goodsname}}
     <hr>
     {{getUsername}}
     {{getGoodsname}}
     {{getGoodsnameNew}}
     <hr>
     <button @click="setGoodsname('电脑')">点击修改商品名称</button>
     <button @click="setUsername('曹操')">点击修改用户名</button>
     <hr>
     {{goodsList}}
     <button @click="getGoodsListAction()">点击获取商品列表</button>
 </div>
</template>

<script>
// 辅助函数
import {mapState,mapGetters,mapMutations,mapActions} from 'vuex'
export default {
    data(){
         return{
         }
    },
    computed:{
        // 数据
        // 没有子模块
        ...mapState(['username']),
        // 子模块
        ...mapState({goodsname:state=>state.goods.goodsname,goodsList:state=>state.goods.goodsList}),
        // 没有子模块
        ...mapGetters(['getUsername']),
        // 子模块
        ...mapGetters('goods',['getGoodsname','getGoodsnameNew'])
    },
    created(){
    },
    methods:{
        // 方法
        // 没有子模块
        ...mapMutations(['setUsername']),
        // 子模块
        ...mapMutations('goods',['setGoodsname']),
        // 子模块
        ...mapActions('goods',['getGoodsListAction'])
    },
    components:{}
}

</script>
<style scoped>
.goods {
    width: 500px;
    border: 5px solid #000;
    background-color: rgb(102, 236, 24);
}
</style>