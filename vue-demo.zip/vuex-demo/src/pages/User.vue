<template>
 <div class="user">
     <h1>用户</h1>
     <hr>
     <h3>{{$store.state.username}}</h3>
     <h3>{{$store.state.nickname}}</h3>
     <h3>{{$store.getters.getUsername}}</h3>
     <h3>{{$store.state.brandList}}</h3>
     <hr>
     <h3>{{$store.state.user.userList}}</h3>
     <h3>{{$store.getters['user/getUsercount']}}</h3>
     <hr>
     <button @click="$store.commit('user/setUsercount',20)">点击修改用户数量</button>
     <button @click="$store.dispatch('user/getUserListAction')">点击获取用户列表</button>
 </div>
</template>

<script>
export default {
    data(){
         return{}
    },
    created(){},
    methods:{},
    components:{}
}

</script>
<style scoped>
.user {
    width: 500px;
    border: 5px solid #000;
    background-color: gold;
}
</style>