<template>
 <div class="home">
     <h1>主页</h1>
     <hr>
     <h3>{{$store.state.username}}</h3>
     <h3>{{$store.state.nickname}}</h3>
     <h3>{{$store.getters.getUsername}}</h3>
     <h3>{{$store.state.brandList}}</h3>
     <hr>
     <button @click="setUsername()">点击修改username</button>
     <button @click="getBrandList()">点击获取brandList</button>
 </div>
</template>

<script>
export default {
    data(){
         return{}
    },
    created(){
        // console.log(this.$store)
    },
    methods:{
        setUsername(){
            // commit就是用来调用mutations里面的方法
            /*
                格式：this.$store.commit('方法名','更新的值')
            */ 
            this.$store.commit('setUsername','刘备')
        },
        getBrandList(){
            // dispatch就是用来调用actions里面的方法
            this.$store.dispatch('getBrandListAction')
        }
    },
    components:{}
}

</script>
<style scoped>
.home {
    width: 500px;
    border: 5px solid #000;
    background-color: pink;
}
</style>