<template>
  <div class="container">
    <!-- <Home/>
    <User/>
    <Goods/> -->
    <ElementUI/>
  </div>
</template>

<script>
import Home from './pages/Home'
import User from './pages/User'
import Goods from './pages/Goods'
import ElementUI from './pages/ElementUI'
export default {
  name: 'App',
  components:{
    Home,User,Goods,ElementUI
  }
}
</script>

<style>
.container {
  display: flex;
  margin: 0 auto;
}
</style>
